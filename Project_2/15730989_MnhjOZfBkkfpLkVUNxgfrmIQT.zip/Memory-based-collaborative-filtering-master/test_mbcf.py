#coding=utf-8

class TestClass:

    def test_one(self):
        x = "this"

    def test_two(self):
        x = "hello"
