# UserCF基于用户的协同过滤推荐实现 

UserCF的思想见博客：http://blog.csdn.net/u012050154/article/details/52268057    
UserCF.py是代码实现
UserCF.png是程序运行结果 

关于推荐系统的介绍见博客：http://blog.csdn.net/u012050154/article/details/52267712
